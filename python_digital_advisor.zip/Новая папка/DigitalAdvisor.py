from selenium.webdriver.support import expected_conditions as EC
from sklearn.feature_extraction.text import TfidfVectorizer
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.support.ui import WebDriverWait
from sklearn.metrics.pairwise import cosine_similarity
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from urllib.parse import urlparse, urljoin
import json, re, requests, time, random
from collections import Counter
from selenium import webdriver
from bs4 import BeautifulSoup
from openai import OpenAI

class DA:
    def __init__(self, url):
        self.url = url
        self.listPage = list()

        self.data = {
            "keywords": list(),
            "base_seo": dict(),
            "readability": 0,
            "favicon": "",
            "robot_index": None,
            "social_links": list(),
            "uniqueness_pages": dict(),
            "uniqueness_internet": 0,
            "very_frequency_keyword": list()
        }
        self.log = {"robot_txt": ""}

        self.client = OpenAI(
            api_key="sk-30a13f977e7342d1b1990c8ccb02bac0",
            base_url="https://api.deepseek.com"
        )

    def FullAnalysis(self):
        print("Start SEO analys")
        tm1 = time.time()

        self.listPage = self.SearchPageOnSite()

        keywords = self.SearchKeywords()
        self.data["keywords"] = [item["word"] for item in keywords]

        self.data["base_seo"] = self.BaseSEOAnaliz()

        self.data["readability"] = self.CalculateReadability()

        self.data["favicon"] = self.SearchFavicon()

        self.data["robot_index"], self.log["robot_txt"] = self.RobotIndexTest()

        social_links = list()
        for link in self.listPage:
            social_links = social_links + list(self.SearchSocialLinks(link)["social_links"])
        for i in range(len(social_links)):
            social_links[i] = social_links[i].lower()
        self.data["social_links"] = list(set(social_links))

        self.data["uniqueness_pages"] = self.UniquenessPagesOnSite()

        self.data["very_frequency_keyword"] = self.KeywordFrequency()

        self.data["uniqueness_internet"] = self.UniquenessInInternet()

        estimation = self.EstimateAnalysis()
        average_estimation = sum(estimation.values()) / len(estimation)
        verdict, recommendations = self.GetRecommendation()

        print(f"Finish SEO analys: {time.time() - tm1} s")

        return {
            "data": self.data,
            "log": self.log,
            "tm": time.time() - tm1,
            "estimation": estimation,
            "average_estimation": average_estimation,
            "verdict": verdict,
            "recommendations": recommendations,
            "checklist": recommendations
        }

    def getPageText(self, url):
        try:
            response = requests.get(url, timeout=10, headers={
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            })
            soup = BeautifulSoup(response.text, 'html.parser')

            for script in soup(["script", "style", "nav", "footer", "header"]):
                script.decompose()

            text = soup.get_text(separator=' ', strip=True)
            text = re.sub(r'\s+', ' ', text)

            return text[:3000]
        except Exception as e:
            print(f"Ошибка при загрузке {url}: {e}")
            return ""

    def SearchPageOnSite(self):
        response = requests.get(self.url, timeout=10)
        soup = BeautifulSoup(response.text, 'html.parser')

        base_domain = urlparse(self.url).netloc
        internal_links = set()

        for link in soup.find_all("a", href=True):
            href = link["href"]
            full_url = urljoin(self.url, href)
            if urlparse(full_url).netloc == base_domain:
                internal_links.add(full_url)

        return list(internal_links)

    def SearchKeywords(self):
        internal_links = self.listPage

        if self.url not in internal_links:
            internal_links.insert(0, self.url)

        all_content = []

        for i, link in enumerate(internal_links[:20], 1):
            page_text = self.getPageText(link)
            if page_text:
                all_content.append(f"=== СТРАНИЦА {i}: {link} ===\n{page_text}\n")

        full_site_text = "\n".join(all_content)

        prompt = f"""
            Ты эксперт по SEO и анализу сайтов. Проанализируй содержимое сайта "{self.url}" и определи ТОП-10 ключевых слов, которые наиболее точно характеризуют деятельность компании.

            **Важные требования:**
            1. Игнорируй технические страницы (политика конфиденциальности, cookie, юридические документы)
            2. Игнорируй общие слова (сайт, страница, ссылка, меню, кнопка и т.д.)
            3. Слова должны отражать СУТЬ бизнеса/услуг компании
            4. Учитывай частоту, но важнее — смысловую значимость
            5. Выдай ТОЛЬКО JSON без лишнего текста

            Вот содержимое страниц сайта:
            {full_site_text[:50000]}

            Ответь в формате:
            {{
                "keywords": [
                    {{"word": "ключевое_слово_1", "reason": "почему оно важно"}},
                    {{"word": "ключевое_слово_2", "reason": "почему оно важно"}},
                    ...
                ]
            }}
            """

        try:
            api_response = self.client.chat.completions.create(
                model="deepseek-reasoner",
                messages=[
                    {"role": "system",
                     "content": "Ты — эксперт по SEO-анализу. Отвечай только JSON без markdown-разметки."},
                    {"role": "user", "content": prompt},
                ],
                temperature=0.3,
                stream=False
            )

            content = api_response.choices[0].message.content

            content = re.sub(r'```json\n?', '', content)
            content = re.sub(r'```\n?', '', content)
            content = content.strip()

            data = json.loads(content)
            return data.get("keywords", [])

        except Exception as e:
            print(f"Ошибка при запросе к API: {e}")
            return []

    def BaseSEOAnaliz(self):
        try:
            start_time = time.time()
            response = requests.get(self.url, timeout=10)
            load_time = time.time() - start_time

            soup = BeautifulSoup(response.text, 'html.parser')
            title = soup.title.string if soup.title else "Отсутствует"
            meta_description = soup.find("meta", attrs={"name": "description"})
            meta_description = meta_description["content"] if meta_description else "Отсутствует"

            return {
                "url": self.url,
                "status": response.status_code,
                "load_time": f"{load_time:.2f} сек",
                "title": title,
                "meta_description": meta_description
            }
        except Exception as e:
            return {"url": self.url, "error": str(e)}

    def CalculateReadability(self):
        text = self.getPageText(self.url)

        sentences = re.split(r'[.!?]', text)
        sentences = [s.strip() for s in sentences if s.strip()]
        sentence_count = len(sentences)

        words = re.findall(r'\b\w+\b', text)
        word_count = len(words)

        syllables = 0
        for word in words:
            syllables += len(re.findall(r'[аеёиоуыэюяaeiouy]+', word.lower()))

        if sentence_count == 0 or word_count == 0:
            return {"readability": "Невозможно вычислить"}

        asl = word_count / sentence_count
        asw = syllables / word_count

        readability = 206.835 - 1.015 * asl - 84.6 * asw
        return readability

    def SearchFavicon(self):
        response = requests.get(self.url, timeout=10)
        soup = BeautifulSoup(response.text, 'html.parser')

        favicon = soup.find("link", rel="icon") or soup.find("link", rel="shortcut icon")
        favicon_url = favicon["href"] if favicon else None

        return favicon_url

    def RobotIndexTest(self):
        parsed_url = urlparse(self.url)
        robots_url = f"{parsed_url.scheme}://{parsed_url.netloc}/robots.txt"

        try:
            response = requests.get(robots_url, timeout=10)
            if response.status_code == 200:
                return True, response.text
            else:
                return False, "Файл не найден"
        except Exception as e:
            return False, str(e)

    def SearchSocialLinks(self, url):
        response = requests.get(url, timeout=10)
        soup = BeautifulSoup(response.text, 'html.parser')
        social_links = set()
        social_networks = ["facebook.com", "vk.com", "instagram.com", "twitter.com", "telegram.me", "t.me"]
        for link in soup.find_all("a", href=True):
            for network in social_networks:
                if network in link["href"]:
                    social_links.add(link["href"])
        return {"url": url, "social_links": social_links}

    def UniquenessPagesOnSite(self):
        data = list()

        for link in self.listPage:
            data.append(self.getPageText(link))

        vectorizer = TfidfVectorizer()
        tfidf_matrix = vectorizer.fit_transform(data)
        similarity = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:2])[0][0]

        uniqueness = 1 - similarity
        return {"uniqueness": f"{uniqueness:.2f}", "similarity": f"{similarity:.2f}"}

    def KeywordFrequency(self):
        internal_links = self.listPage

        if self.url not in internal_links:
            internal_links.insert(0, self.url)

        all_content = []

        for i, link in enumerate(internal_links[:20], 1):
            page_text = self.getPageText(link)
            if page_text:
                all_content.append(f"\n{page_text}\n")

        text = "\n".join(all_content)

        stop_words = {"и", "в", "на", "с", "по", "из", "от", "к", "за", "при", "а", "но", "да", "нет", "для", "среди", "не", "перейти", "я", "можно"}

        words = re.findall(r'\b\w+\b', text.lower())
        filtered_words = [word for word in words if word not in stop_words]
        word_counts = Counter(filtered_words)
        return word_counts.most_common(10)

    def SetupDriver(self):
        chrome_options = Options()
        chrome_options.add_argument("--disable-blink-features=AutomationControlled")
        chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
        chrome_options.add_experimental_option('useAutomationExtension', False)
        chrome_options.add_argument(
            "user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")

        service = Service(ChromeDriverManager().install())
        driver = webdriver.Chrome(service=service, options=chrome_options)
        driver.execute_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")

        return driver

    def SearchInInternet(self, query, num_results=20):
        driver = None
        results = []

        try:
            driver = self.SetupDriver()
            driver.get("https://www.bing.com/")
            time.sleep(random.uniform(1, 2))

            search_box = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.NAME, "q"))
            )

            for char in query:
                search_box.send_keys(char)
                time.sleep(random.uniform(0.03, 0.1))

            time.sleep(random.uniform(0.3, 0.8))
            search_box.send_keys(Keys.RETURN)

            time.sleep(random.uniform(2, 4))

            search_results = driver.find_elements(By.CSS_SELECTOR, "li.b_algo")

            count = 0
            for result in search_results:
                if count >= num_results:
                    break

                try:
                    link_element = result.find_element(By.CSS_SELECTOR, "a")
                    url = link_element.get_attribute("href")

                    title_element = result.find_element(By.CSS_SELECTOR, "h2")
                    title = title_element.text

                    try:
                        desc_element = result.find_element(By.CSS_SELECTOR, "div.b_caption p")
                        description = desc_element.text
                    except:
                        description = ""

                    if url and url.startswith("http") and title:
                        results.append([url, title, description])
                        count += 1

                except Exception as e:
                    continue

        except Exception as e:
            print(f"❌ Ошибка: {e}")

        finally:
            if driver:
                driver.quit()

        return results

    def UniquenessInInternet(self):
        other_urls = []

        for query in self.data["keywords"]:
            results = self.SearchInInternet(query, num_results=10)
            for i, item in enumerate(results, 1):
                url, name, description = item
                other_urls.append(url)

        texts = [self.getPageText(self.url)]
        for url in other_urls:
            response = requests.get(url, timeout=20)
            soup = BeautifulSoup(response.text, 'html.parser')
            texts.append(soup.get_text(separator=' ', strip=True))

        vectorizer = TfidfVectorizer()
        tfidf_matrix = vectorizer.fit_transform(texts)
        similarity_matrix = (tfidf_matrix * tfidf_matrix.T).toarray()

        uniqueness = 1 - similarity_matrix[0][1:]
        print(uniqueness)
        try:
            answer = uniqueness.mean()
        except Exception as e:
            answer = 0

        return answer

    def EstimateAnalysis(self):
        estimation = {
            "keywords": 3,
            "base_seo": 4,
            "readability": 3,
            "favicon": 5 if self.data["favicon"] else 1,
            "robot_index": 5 if self.data["robot_index"] else 1,
            "social_links": 5 if len(self.data["social_links"]) > 0 else 1,
            "uniqueness_pages": int(float(self.data["uniqueness_pages"]["uniqueness"]) * 5),
            "uniqueness_internet": int(self.data["uniqueness_internet"] * 5)
        }
        return estimation

    def GetRecommendation(self):
        prompt = f"""
        Ты эксперт по SEO. Напиши краткий вердикт (2-3 предложения) и дай 5-10 коротких рекомендаций по улучшению сайта {self.url} на основе следующих данных:
        {json.dumps(self.data, ensure_ascii=False, indent=2)}
        Ответь в формате:
        {{
            "verdict": "краткий вердикт",
            "recommendations": ["рекомендация 1", "рекомендация 2", ...]
        }}
        """
        try:
            api_response = self.client.chat.completions.create(
                model="deepseek-reasoner",
                messages=[
                    {"role": "system", "content": "Ты — эксперт по SEO-анализу. Отвечай только JSON без markdown-разметки."},
                    {"role": "user", "content": prompt},
                ],
                temperature=0.3,
                stream=False
            )
            content = api_response.choices[0].message.content
            content = re.sub(r'```json\n?', '', content)
            content = re.sub(r'```\n?', '', content)
            content = content.strip()
            data = json.loads(content)
            return data.get("verdict", ""), data.get("recommendations", [])
        except Exception as e:
            print(f"Ошибка при запросе к API: {e}")
            return "Не удалось получить рекомендации.", []

# # Пример использования
# test = DA("https://alexgyver.ru/")
# result = test.FullAnalysis()
#
# print("Data:", result["data"])
# print("Log:", result["log"])
# print("Time:", result["tm"])
# print("Estimation:", result["estimation"])
# print("Average Estimation:", result["average_estimation"])
# print("Verdict:", result["verdict"])
# print("Recommendations:", result["recommendations"])
# print("Checklist:", result["checklist"])