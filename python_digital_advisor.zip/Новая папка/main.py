import tkinter as tk
from tkinter import messagebox
import qrcode
from PIL import Image
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image as ReportlabImage, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
import io
import os
import json
from datetime import datetime
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.options import Options

from DigitalAdvisor import DA

class SEOAnalyzerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("SEO Analyzer")

        # Проверяем наличие шрифта
        font_path = "DejaVuSans.ttf"
        if not os.path.exists(font_path):
            messagebox.showerror(
                "Ошибка",
                f"Шрифт {font_path} не найден! Скачайте его и положите в папку со скриптом."
            )
            self.root.destroy()
            return

        # Регистрируем шрифт
        pdfmetrics.registerFont(TTFont("DejaVuSans", font_path))

        # Поле для ввода URL
        self.url_label = tk.Label(root, text="Введите URL сайта:")
        self.url_label.pack(pady=5)

        self.url_entry = tk.Entry(root, width=50)
        self.url_entry.pack(pady=5)

        # Кнопки
        self.analyze_button = tk.Button(root, text="Проанализировать", command=self.run_analysis)
        self.analyze_button.pack(pady=5)

        self.debug_button = tk.Button(
            root,
            text="Отладка: Пройти тест на робота (Bing)",
            command=self.open_bing_for_captcha
        )
        self.debug_button.pack(pady=5)

        self.generate_from_log_button = tk.Button(
            root,
            text="Сгенерировать PDF из лога",
            command=self.generate_pdf_from_log
        )
        self.generate_from_log_button.pack(pady=5)

        # Метка статуса
        self.status_label = tk.Label(root, text="")
        self.status_label.pack(pady=5)

    def open_bing_for_captcha(self):
        """Открывает Bing в браузере для ручного прохождения капчи."""
        try:
            chrome_options = Options()
            chrome_options.add_argument("--disable-blink-features=AutomationControlled")
            chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
            chrome_options.add_experimental_option('useAutomationExtension', False)
            chrome_options.add_argument(
                "user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
            )

            service = Service(ChromeDriverManager().install())
            driver = webdriver.Chrome(service=service, options=chrome_options)
            driver.execute_script("Object.defineProperty(navigator, 'webdriver', {get: () => undefined})")

            driver.get("https://www.bing.com/")
            self.status_label.config(text="Открыт Bing для ручного прохождения капчи.")

        except Exception as e:
            messagebox.showerror("Ошибка", f"Не удалось открыть браузер: {e}")

    def run_analysis(self):
        url = self.url_entry.get().strip()
        if not url:
            messagebox.showerror("Ошибка", "Пожалуйста, введите URL!")
            return

        self.status_label.config(text="Анализ запущен...")

        try:
            analyzer = DA(url)
            result = analyzer.FullAnalysis()

            self.save_to_log(result, url)
            self.generate_pdf_report(result, url)
            self.status_label.config(text="Анализ завершён! Отчёт сгенерирован.")

        except Exception as e:
            self.status_label.config(text=f"Ошибка: {str(e)}")
            messagebox.showerror("Ошибка", f"Не удалось выполнить анализ: {e}")

    def save_to_log(self, result, url):
        """Сохраняет результат анализа в JSON-лог."""
        log_entry = {
            "url": url,
            "timestamp": datetime.now().isoformat(),
            "data": result
        }

        log_file = "seo_report_log.json"
        if os.path.exists(log_file):
            with open(log_file, "r", encoding="utf-8") as f:
                log_data = json.load(f)
        else:
            log_data = []

        log_data.append(log_entry)

        with open(log_file, "w", encoding="utf-8") as f:
            json.dump(log_data, f, ensure_ascii=False, indent=4)

    def generate_pdf_from_log(self):
        """Генерирует PDF-отчёт из последней записи лога."""
        log_file = "seo_report_log.json"
        if not os.path.exists(log_file):
            messagebox.showerror("Ошибка", "Лог-файл не найден!")
            return

        with open(log_file, "r", encoding="utf-8") as f:
            log_data = json.load(f)

        if not log_data:
            messagebox.showerror("Ошибка", "Лог пуст!")
            return

        last_entry = log_data[-1]
        self.generate_pdf_report(last_entry["data"], last_entry["url"])
        self.status_label.config(text="PDF сгенерирован из последней записи лога.")

    def generate_pdf_report(self, result, url):
        """Генерирует PDF-отчёт."""
        filename = f"seo_report_{url.replace('https://', '').replace('http://', '').replace('/', '_')}.pdf"
        doc = SimpleDocTemplate(filename, pagesize=letter)
        styles = getSampleStyleSheet()

        # Настраиваем стили для кириллицы
        style_keys = ["Normal", "Title", "Heading1", "Heading2"]
        for key in style_keys:
            styles[key].fontName = "DejaVuSans"

        story = []

        # --- 1. Титульная страница ---
        qr = qrcode.QRCode(version=1, box_size=10, border=5)
        qr.add_data(url)
        qr.make(fit=True)
        qr_img = qr.make_image(fill_color="black", back_color="white")
        qr_img_bytes = io.BytesIO()
        qr_img.save(qr_img_bytes, format="PNG")
        qr_img_bytes.seek(0)

        story.append(Paragraph(f"<b>Отчёт по SEO-анализу сайта:</b> {url}", styles["Title"]))
        story.append(Spacer(1, 0.2 * inch))

        # Логотип (если есть)
        # favicon_url = result["data"].get("favicon")
        # if favicon_url:
        #     try:
        #         import requests
        #         from PIL import Image as PILImage
        #         from io import BytesIO
        #
        #         if favicon_url.startswith(('http://', 'https://')):
        #             response = requests.get(favicon_url, stream=True, timeout=5)
        #             if response.status_code == 200:
        #                 content_type = response.headers.get('Content-Type', '')
        #                 if content_type.startswith('image/'):
        #                     favicon_img = PILImage.open(BytesIO(response.content))
        #                     favicon_img_bytes = io.BytesIO()
        #                     favicon_img.save(favicon_img_bytes, format="PNG")
        #                     favicon_img_bytes.seek(0)
        #                     story.append(ReportlabImage(favicon_img_bytes, width=1 * inch, height=1 * inch))
        #                     story.append(Spacer(1, 0.2 * inch))
        #                 else:
        #                     print(f"Файл не является изображением: {content_type}")
        #             else:
        #                 print(f"Ошибка загрузки фавикона: HTTP {response.status_code}")
        #         else:
        #             print(f"Некорректный URL фавикона: {favicon_url}")
        #     except Exception as e:
        #         print(f"Ошибка загрузки фавикона: {e}")

        # Название и описание
        title = result["data"]["base_seo"].get("title", "Нет данных")
        description = result["data"]["base_seo"].get("meta_description", "Нет данных")

        story.append(Paragraph(f"<b>Название:</b> {title}", styles["Normal"]))
        story.append(Paragraph(f"<b>Описание:</b> {description}", styles["Normal"]))
        story.append(ReportlabImage(qr_img_bytes, width=2 * inch, height=2 * inch))
        story.append(Spacer(1, 0.5 * inch))

        # --- 2. Вердикт ---
        verdict = result.get("verdict", "Нет вердикта")
        story.append(Paragraph(f"<b>Вердикт:</b> {verdict}", styles["Normal"]))
        story.append(Spacer(1, 0.5 * inch))

        # --- 3. Оценки ---
        estimation = result.get("estimation", {})
        if estimation:
            data = [["Параметр", "Оценка"]]
            for key, value in estimation.items():
                data.append([key, str(value)])

            table = Table(data)
            table.setStyle(TableStyle([
                ("BACKGROUND", (0, 0), (-1, 0), colors.grey),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.whitesmoke),
                ("ALIGN", (0, 0), (-1, -1), "CENTER"),
                ("FONTNAME", (0, 0), (-1, 0), "DejaVuSans"),
                ("BOTTOMPADDING", (0, 0), (-1, 0), 12),
                ("BACKGROUND", (0, 1), (-1, -1), colors.beige),
                ("GRID", (0, 0), (-1, -1), 1, colors.black),
            ]))
            story.append(Paragraph(f"<b>Итоговый средний балл:</b> {result.get('average_estimation', 0):.2f}",
                                   styles["Heading2"]))
            story.append(Spacer(1, 0.2 * inch))
            story.append(table)
            story.append(Spacer(1, 0.5 * inch))

        # --- 4. Чек-лист ---
        checklist = result.get("checklist", [])
        story.append(Paragraph("<b>Чек-лист для улучшения:</b>", styles["Heading2"]))
        for item in checklist:
            story.append(Paragraph(f"[ ] {item}", styles["Normal"]))

        # Сохраняем PDF
        doc.build(story)
        messagebox.showinfo("Готово", f"Отчёт сохранён как {filename}")

if __name__ == "__main__":
    root = tk.Tk()
    app = SEOAnalyzerApp(root)
    root.mainloop()