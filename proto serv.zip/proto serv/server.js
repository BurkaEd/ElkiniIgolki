
const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const fsp = require('fs/promises');
const cheerio = require('cheerio');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json({ limit: '2mb' }));
app.use(express.static(path.join(__dirname, 'public')));
app.get('/', (_, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

const PORT = process.env.PORT || 3000;
const GOOGLE_KEY = process.env.GOOGLE_PAGESPEED_API_KEY || '';
const VSEGPT_KEY = process.env.VSEGPT_API_KEY || '';
const VSEGPT_MODEL = process.env.VSEGPT_MODEL || 'deepseek/deepseek-chat-3.1-alt-fast';
const BASE_URL = process.env.BASE_URL || `http://localhost:${PORT}`;
const JOB_INTERVAL_MINUTES = Number(process.env.JOB_INTERVAL_MINUTES || 30);
const DATA_DIR = path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');
const KNOWLEDGE_FILE = path.join(DATA_DIR, 'knowledge-base.json');
const RULES_FILE = path.join(DATA_DIR, 'rules.json');
const MAX_CRAWL_PAGES = Number(process.env.MAX_CRAWL_PAGES || 8);

function ensureFiles() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(DB_FILE)) {
    fs.writeFileSync(DB_FILE, JSON.stringify({
      users: [
        { id: 'u_owner', name: 'Андрей', role: 'owner', email: 'owner@local.dev' },
        { id: 'u_marketer', name: 'Маркетолог', role: 'marketer', email: 'marketer@local.dev' },
        { id: 'u_dev', name: 'Разработчик', role: 'developer', email: 'dev@local.dev' }
      ],
      projects: [], audits: [], jobs: [], reports: []
    }, null, 2));
  }
  if (!fs.existsSync(KNOWLEDGE_FILE)) {
    fs.writeFileSync(KNOWLEDGE_FILE, JSON.stringify({
      updatedAt: new Date().toISOString(),
      categories: {
        seo: [
          'Title должен быть понятным, предметным и не слишком коротким.',
          'Meta description повышает качество сниппета и CTR.',
          'Robots.txt и sitemap.xml помогают базовой индексации.',
          'Canonical снижает риск дублей.'
        ],
        ux: [
          'На первом экране нужен понятный оффер и заметный CTA.',
          'Сайт должен быть удобным на мобильных устройствах.',
          'Пользователь должен быстро понимать, что делать дальше.'
        ],
        trust: [
          'Контакты, отзывы, кейсы и реквизиты усиливают доверие.',
          'HTTPS обязателен для современной цифровой среды.',
          'Карточки компании усиливают локальную конверсию.'
        ],
        analytics: [
          'Счетчики аналитики позволяют измерять реальный результат.',
          'Наличие метрик помогает строить data-driven решения.',
          'Без аналитики сложнее оценивать влияние изменений.'
        ],
        social: [
          'Соцсети должны быть связаны с сайтом и единым брендом.',
          'Важно наличие ссылки, описания и регулярной активности.',
          'Соцканалы усиливают доверие и удержание внимания.'
        ]
      }
    }, null, 2));
  }
  if (!fs.existsSync(RULES_FILE)) {
    fs.writeFileSync(RULES_FILE, JSON.stringify({
      updatedAt: new Date().toISOString(),
      formula: 'Общий коэффициент = среднее арифметическое всех критериев.',
      criteria: {
        performance: { weight: 1, title: 'Скорость', description: 'Скорость и техническая производительность по PageSpeed/Lighthouse.' },
        accessibility: { weight: 1, title: 'Доступность', description: 'Базовая доступность интерфейса.' },
        seo: { weight: 1, title: 'SEO', description: 'Поисковые сигналы по PageSpeed и структуре сайта.' },
        metadata: { weight: 1, title: 'Метаданные', description: 'Title, description, canonical и OG-элементы.' },
        structure: { weight: 1, title: 'Структура', description: 'H1/H2, логика страниц, CTA и навигация.' },
        trust: { weight: 1, title: 'Доверие', description: 'Контакты, HTTPS, отзывы, кейсы и локальные сигналы.' },
        analytics: { weight: 1, title: 'Аналитика', description: 'Наличие счетчиков Яндекс Метрики, Google Analytics, GTM, пикселей.' },
        social: { weight: 1, title: 'Соцсети', description: 'Наличие и качество связанных социальных каналов.' },
        local: { weight: 1, title: 'Карточки компании', description: 'Локальные карточки и сигналы присутствия на картах.' },
        crawl: { weight: 1, title: 'Масштаб сайта', description: 'Оценка нескольких страниц сайта, а не только главной.' }
      }
    }, null, 2));
  }
}
ensureFiles();

async function readJson(file) { return JSON.parse(await fsp.readFile(file, 'utf-8')); }
async function writeJson(file, data) { await fsp.writeFile(file, JSON.stringify(data, null, 2)); }
function uid(prefix='id') { return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2,8)}`; }
function clamp(n,min,max){ return Math.max(min, Math.min(max, n)); }
function avg(arr){ return arr.length ? Math.round(arr.reduce((a,b)=>a+b,0)/arr.length) : 0; }
function normUrl(value){ let url = String(value || '').trim(); if(!/^https?:\/\//i.test(url)) url = 'https://' + url; return url; }
function absoluteUrl(base, maybe){ try { return new URL(maybe, base).toString(); } catch { return maybe || ''; } }
function cleanText(x){ return String(x || '').replace(/\s+/g,' ').trim(); }

async function fetchPageSpeed(url) {
  const endpoint = new URL('https://www.googleapis.com/pagespeedonline/v5/runPagespeed');
  endpoint.searchParams.set('url', url);
  endpoint.searchParams.set('strategy', 'mobile');
  endpoint.searchParams.append('category', 'performance');
  endpoint.searchParams.append('category', 'accessibility');
  endpoint.searchParams.append('category', 'seo');
  if (GOOGLE_KEY) endpoint.searchParams.set('key', GOOGLE_KEY);
  const r = await fetch(endpoint.toString());
  const txt = await r.text();
  if (!r.ok) throw new Error(`PageSpeed ${r.status}: ${txt.slice(0,200)}`);
  return JSON.parse(txt);
}

async function fetchHtml(url) {
  const r = await fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0 GrowthAuditorBot/4.0' } });
  if (!r.ok) throw new Error(`HTML ${r.status}`);
  return await r.text();
}

function detectAnalytics(html) {
  const h = String(html || '').toLowerCase();
  return {
    yandexMetrica: /mc\.yandex\.ru|ym\(/i.test(html),
    googleAnalytics: /gtag\(|google-analytics\.com|ga\(/i.test(html),
    googleTagManager: /googletagmanager\.com|gtm-/i.test(html),
    vkPixel: /vk\.com\/js\/api\/openapi|vk_retarg/i.test(html),
    metaPixel: /connect\.facebook\.net|fbq\(/i.test(html)
  };
}

function socialMap() {
  return { instagram: [], vk: [], telegram: [], youtube: [], tiktok: [], dzen: [], ok: [], facebook: [] };
}

function extractSocialLinks($, url) {
  const map = socialMap();
  $('a[href]').each((_, el) => {
    const href = ($(el).attr('href') || '').trim();
    const full = absoluteUrl(url, href);
    const low = full.toLowerCase();
    if (low.includes('instagram.com')) map.instagram.push(full);
    if (low.includes('vk.com')) map.vk.push(full);
    if (low.includes('t.me') || low.includes('telegram.me')) map.telegram.push(full);
    if (low.includes('youtube.com') || low.includes('youtu.be')) map.youtube.push(full);
    if (low.includes('tiktok.com')) map.tiktok.push(full);
    if (low.includes('dzen.ru')) map.dzen.push(full);
    if (low.includes('ok.ru')) map.ok.push(full);
    if (low.includes('facebook.com')) map.facebook.push(full);
  });
  return Object.fromEntries(Object.entries(map).map(([k,v]) => [k, [...new Set(v)].slice(0,5)]));
}

function mergeSocialMaps(maps) {
  const out = socialMap();
  for (const m of maps) {
    for (const [k, arr] of Object.entries(m || {})) out[k] = [...new Set([...(out[k] || []), ...(arr || [])])].slice(0, 8);
  }
  return out;
}

function detectCompanyListings($, url) {
  const anchors = [];
  $('a[href]').each((_, el) => anchors.push(absoluteUrl(url, $(el).attr('href') || '')));
  const uniq = [...new Set(anchors)];
  return {
    yandexMaps: uniq.filter(x => x.includes('yandex.') && x.includes('/maps')).slice(0,5),
    twoGis: uniq.filter(x => x.includes('2gis.')).slice(0,5),
    googleMaps: uniq.filter(x => x.includes('google.') && x.includes('/maps')).slice(0,5)
  };
}

function mergeListings(listings) {
  const out = { yandexMaps: [], twoGis: [], googleMaps: [] };
  for (const l of listings) {
    out.yandexMaps = [...new Set([...out.yandexMaps, ...(l?.yandexMaps || [])])].slice(0,8);
    out.twoGis = [...new Set([...out.twoGis, ...(l?.twoGis || [])])].slice(0,8);
    out.googleMaps = [...new Set([...out.googleMaps, ...(l?.googleMaps || [])])].slice(0,8);
  }
  return out;
}

async function analyzeSocialProfile(url) {
  try {
    const r = await fetch(url, { headers: { 'User-Agent': 'Mozilla/5.0 GrowthAuditorBot/4.0' } });
    const html = await r.text();
    const $ = cheerio.load(html);
    const title = cleanText($('title').first().text());
    const metaDescription = cleanText($('meta[name="description"]').attr('content') || $('meta[property="og:description"]').attr('content') || '');
    const hasBio = metaDescription.length > 20;
    const hasSiteLink = /https?:\/\//i.test(html);
    const activityHints = (html.match(/post|video|reel|subscriber|подпис|подписчик|followers|views|stories/gi) || []).length;
    const score = clamp((hasBio ? 35 : 10) + (hasSiteLink ? 25 : 10) + Math.min(activityHints * 4, 40), 0, 100);
    return { url, title, metaDescription, hasBio, hasSiteLink, activityHints, score, status:'ok' };
  } catch (e) {
    return { url, score: 35, status:'limited', error: e.message };
  }
}

async function checkSimpleUrl(url) {
  try {
    const r = await fetch(url, { redirect: 'follow', headers: { 'User-Agent': 'Mozilla/5.0 GrowthAuditorBot/4.0' } });
    return { url, ok: r.ok, status: r.status };
  } catch (e) {
    return { url, ok: false, status: 0, error: e.message };
  }
}

function getPageSignals(url, html) {
  const $ = cheerio.load(html);
  const title = cleanText($('title').first().text());
  const metaDescription = cleanText($('meta[name="description"]').attr('content') || '');
  const canonical = cleanText($('link[rel="canonical"]').attr('href') || '');
  const h1Count = $('h1').length;
  const h2Count = $('h2').length;
  const imgs = $('img').length;
  let altMissing = 0; $('img').each((_, el) => { if(!cleanText($(el).attr('alt'))) altMissing += 1; });
  let internalLinks = 0, externalLinks = 0;
  $('a[href]').each((_, el) => {
    const href = $(el).attr('href');
    try { new URL(href, url).hostname === new URL(url).hostname ? internalLinks++ : externalLinks++; } catch { internalLinks++; }
  });
  const viewport = $('meta[name="viewport"]').length > 0;
  const lang = $('html').attr('lang') || '';
  const bodyText = $('body').text() || '';
  const hasContact = /contact|контакт|phone|tel|email|почта|адрес|whatsapp|telegram/i.test(bodyText);
  const hasCTA = /купить|заказать|оставить заявку|связаться|подробнее|buy|order|contact us|request|записаться/i.test(bodyText);
  const hasReviews = /отзывы|reviews|кейсы|clients|наши клиенты/i.test(bodyText);
  const ogTitle = cleanText($('meta[property="og:title"]').attr('content') || '');
  const ogDescription = cleanText($('meta[property="og:description"]').attr('content') || '');
  const analytics = detectAnalytics(html);
  const analyticsCount = Object.values(analytics).filter(Boolean).length;
  const titleScore = title.length >= 20 && title.length <= 70 ? 100 : title ? 60 : 0;
  const descriptionScore = metaDescription.length >= 70 && metaDescription.length <= 170 ? 100 : metaDescription ? 60 : 0;
  const structureScore = h1Count === 1 ? 100 : h1Count > 1 ? 60 : 20;
  const altScore = imgs ? Math.round((1 - altMissing / imgs) * 100) : 60;
  const trustScore = (hasContact ? 30 : 0) + (hasReviews ? 20 : 0) + (canonical ? 10 : 0) + (viewport ? 10 : 0) + (lang ? 10 : 0) + (hasCTA ? 20 : 0);
  const contentScore = clamp(Math.round((Math.min(internalLinks, 30) / 30) * 45 + (Math.min(h2Count, 8) / 8) * 35 + (hasCTA ? 20 : 0)), 0, 100);
  const analyticsScore = clamp(analyticsCount * 25, 0, 100);
  return {
    url, title, metaDescription, canonical, h1Count, h2Count, imgs, altMissing, internalLinks, externalLinks, viewport, lang, hasContact, hasCTA, hasReviews,
    ogTitle, ogDescription, analytics, analyticsCount,
    scores: { titleScore, descriptionScore, structureScore, altScore, trustScore, contentScore, analyticsScore }
  };
}

async function crawlPages(startUrl, maxPages=MAX_CRAWL_PAGES) {
  const origin = new URL(startUrl).origin;
  const queue = [startUrl];
  const visited = new Set();
  const pages = [];
  while (queue.length && pages.length < maxPages) {
    const url = queue.shift();
    if (visited.has(url)) continue;
    visited.add(url);
    try {
      const html = await fetchHtml(url);
      const signals = getPageSignals(url, html);
      const $ = cheerio.load(html);
      const socialLinks = extractSocialLinks($, url);
      const listings = detectCompanyListings($, url);
      pages.push({ url, html, signals, socialLinks, listings });
      $('a[href]').each((_, el) => {
        if (queue.length + pages.length >= maxPages * 3) return;
        const href = absoluteUrl(url, $(el).attr('href') || '');
        if (!/^https?:/i.test(href)) return;
        try {
          const u = new URL(href);
          if (u.origin !== origin) return;
          if (/\.(pdf|jpg|jpeg|png|gif|svg|webp|zip|doc|docx|xls|xlsx)$/i.test(u.pathname)) return;
          const normalized = u.origin + u.pathname.replace(/\/$/, '') + (u.search || '');
          if (!visited.has(normalized) && !queue.includes(normalized)) queue.push(normalized);
        } catch {}
      });
    } catch {}
  }
  return pages;
}

function mergeAnalytics(pages) {
  const result = { yandexMetrica:false, googleAnalytics:false, googleTagManager:false, vkPixel:false, metaPixel:false };
  for (const p of pages) for (const [k,v] of Object.entries(p.signals.analytics)) if (v) result[k] = true;
  return result;
}

function buildPersonalRecommendations(audit, goal='', context='') {
  const recs = [];
  const textGoal = String(goal || '').toLowerCase();
  const textContext = String(context || '').toLowerCase();
  if (/заяв|лид|продаж|конверс/.test(textGoal + ' ' + textContext)) {
    if (!audit.hasCTA) recs.push({ priority:'high', title:'Усилить конверсионные точки', description:'Добавьте заметный CTA на первом экране, короткую форму заявки и повтор CTA ниже по странице.', effect:'Выше вероятность заявки и ниже потери трафика.' });
    if (!audit.hasContact) recs.push({ priority:'high', title:'Сделать контакты заметнее', description:'Вынесите телефон, мессенджеры и форму связи в шапку и первый экран.', effect:'Пользователю проще довериться и связаться.' });
  }
  if (/seo|трафик|поиск|видим/.test(textGoal + ' ' + textContext)) {
    if (!audit.metaDescription) recs.push({ priority:'high', title:'Добавить meta description на ключевые страницы', description:'Сформируйте description с ценностью и призывом для клика.', effect:'Выше качество сниппета и шанс на переход из поиска.' });
    if (!audit.robots.ok || !audit.sitemap.ok) recs.push({ priority:'medium', title:'Усилить индексацию', description:'Добавьте robots.txt и sitemap.xml, проверьте canonical и внутреннюю перелинковку.', effect:'Поисковикам проще обходить и понимать сайт.' });
  }
  if (/локал|карты|офлайн|гео/.test(textGoal + ' ' + textContext) && audit.listingSignals.score < 60) {
    recs.push({ priority:'high', title:'Усилить локальное присутствие', description:'Добавьте и свяжите карточки Яндекс Карт, 2ГИС и Google Maps, если актуально.', effect:'Выше доверие и больше локальных обращений.' });
  }
  if (audit.analyticsScore < 50) {
    recs.push({ priority:'high', title:'Подключить или проверить аналитику', description:'Установите Яндекс Метрику, Google Analytics или GTM и проверьте корректность установки.', effect:'Появится объективная база для принятия решений.' });
  }
  if (audit.crawlCoverage < 60) {
    recs.push({ priority:'medium', title:'Выстроить структуру нескольких страниц', description:'Проверьте ключевые разделы, чтобы важные страницы не отставали по title, H1, CTA и контактам.', effect:'Сайт станет сильнее не только на главной, но и в целом.' });
  }
  if (audit.psi.performance < 70) {
    recs.push({ priority:'high', title:'Снизить потери из-за скорости', description:'Оптимизируйте изображения, шрифты и сторонние скрипты, чтобы ускорить LCP и TBT.', effect:'Меньше отказов и лучше мобильный опыт.' });
  }
  return recs.slice(0, 8);
}

async function analyzeWebsite(url, businessType='services', goal='', context='') {
  const rules = await readJson(RULES_FILE);
  const psi = await fetchPageSpeed(url);
  const pages = await crawlPages(url, MAX_CRAWL_PAGES);
  if (!pages.length) throw new Error('Не удалось получить страницы сайта для анализа');
  const home = pages[0].signals;
  const mergedSocial = mergeSocialMaps(pages.map(p => p.socialLinks));
  const mergedListings = mergeListings(pages.map(p => p.listings));
  const mergedAnalytics = mergeAnalytics(pages);
  const pageScores = pages.map(p => ({
    metadata: Math.round((p.signals.scores.titleScore + p.signals.scores.descriptionScore) / 2),
    structure: Math.round((p.signals.scores.structureScore + p.signals.scores.contentScore) / 2),
    trust: Math.round((p.signals.scores.trustScore + p.signals.scores.altScore) / 2),
    analytics: p.signals.scores.analyticsScore,
    pageHealth: avg([
      Math.round((p.signals.scores.titleScore + p.signals.scores.descriptionScore) / 2),
      Math.round((p.signals.scores.structureScore + p.signals.scores.contentScore) / 2),
      Math.round((p.signals.scores.trustScore + p.signals.scores.altScore) / 2),
      p.signals.scores.analyticsScore
    ])
  }));
  const perf = Math.round((psi?.lighthouseResult?.categories?.performance?.score || 0) * 100);
  const acc = Math.round((psi?.lighthouseResult?.categories?.accessibility?.score || 0) * 100);
  const seo = Math.round((psi?.lighthouseResult?.categories?.seo?.score || 0) * 100);
  const metadata = avg(pageScores.map(x => x.metadata));
  const structure = avg(pageScores.map(x => x.structure));
  const trust = avg(pageScores.map(x => x.trust));
  const analyticsScore = clamp(Object.values(mergedAnalytics).filter(Boolean).length * 25, 0, 100);
  const socialAnalysis = {};
  for (const [k, arr] of Object.entries(mergedSocial)) socialAnalysis[k] = await Promise.all(arr.map(analyzeSocialProfile));
  const socialScore = avg(Object.values(socialAnalysis).flat().map(x => x.score));
  const listingSignals = {
    total: Object.values(mergedListings).flat().length,
    score: clamp((mergedListings.yandexMaps.length ? 35 : 0) + (mergedListings.twoGis.length ? 35 : 0) + (mergedListings.googleMaps.length ? 30 : 0), 0, 100)
  };
  const crawlCoverage = clamp(Math.round((pages.length / MAX_CRAWL_PAGES) * 100), 0, 100);
  const crawlScore = avg(pageScores.map(x => x.pageHealth));
  const criteria = [
    { key:'performance', title:'Скорость', score: perf, description:'Скорость и техническая производительность по данным PageSpeed.' },
    { key:'accessibility', title:'Доступность', score: acc, description:'Базовая доступность интерфейса и элементов страницы.' },
    { key:'seo', title:'SEO', score: seo, description:'Поисковые сигналы по Lighthouse и структуре.' },
    { key:'metadata', title:'Метаданные', score: metadata, description:'Среднее качество title, description, canonical и OG.' },
    { key:'structure', title:'Структура', score: structure, description:'Средняя оценка заголовков, CTA и логики контента по страницам.' },
    { key:'trust', title:'Доверие', score: trust, description:'Контакты, отзывы, HTTPS и сигналы доверия на страницах.' },
    { key:'analytics', title:'Аналитика', score: analyticsScore, description:'Наличие подключенных счетчиков и измерения результата.' },
    { key:'social', title:'Соцсети', score: socialScore, description:'Наличие и качество соцсетей, найденных на сайте.' },
    { key:'local', title:'Карточки компании', score: listingSignals.score, description:'Наличие карточек и локального цифрового следа.' },
    { key:'crawl', title:'Охват страниц', score: crawlScore, description:'Средняя оценка нескольких проанализированных страниц сайта.' }
  ];
  const total = avg(criteria.map(c => c.score));
  const robots = await checkSimpleUrl(new URL('/robots.txt', url).toString());
  const sitemap = await checkSimpleUrl(new URL('/sitemap.xml', url).toString());
  const brokenCandidates = [];
  for (const p of pages) {
    const $ = cheerio.load(p.html);
    $('a[href]').slice(0, 6).each((_, el) => {
      const href = absoluteUrl(p.url, $(el).attr('href') || '');
      if (/^https?:/i.test(href)) brokenCandidates.push(href);
    });
  }
  const brokenChecks = await Promise.all([...new Set(brokenCandidates)].slice(0, 20).map(checkSimpleUrl));
  const brokenLinks = brokenChecks.filter(x => !x.ok).map(x => ({ url: x.url, status: x.status, error: x.error || '' }));
  const personalizedRecommendations = buildPersonalRecommendations({
    psi:{ performance: perf, accessibility: acc, seo },
    metaDescription: home.metaDescription,
    hasCTA: home.hasCTA,
    hasContact: home.hasContact,
    robots, sitemap,
    listingSignals,
    analyticsScore,
    crawlCoverage
  }, goal, context);

  return {
    url, businessType, goal, context,
    title: home.title, metaDescription: home.metaDescription, canonical: home.canonical, h1Count: home.h1Count, h2Count: home.h2Count,
    imgs: home.imgs, internalLinks: home.internalLinks, externalLinks: home.externalLinks, altMissing: home.altMissing,
    viewport: home.viewport, lang: home.lang, hasContact: home.hasContact, hasCTA: home.hasCTA, hasReviews: home.hasReviews,
    analytics: mergedAnalytics, analyticsScore, pagesAnalyzed: pages.length, crawlCoverage,
    robots, sitemap, brokenLinks,
    companyListings: mergedListings, listingSignals,
    socialLinks: mergedSocial, socialAnalysis,
    pageDetails: pages.map(p => ({
      url: p.url,
      title: p.signals.title,
      metaDescription: p.signals.metaDescription,
      h1Count: p.signals.h1Count,
      h2Count: p.signals.h2Count,
      internalLinks: p.signals.internalLinks,
      externalLinks: p.signals.externalLinks,
      hasCTA: p.signals.hasCTA,
      hasContact: p.signals.hasContact,
      analytics: p.signals.analytics,
      pageHealth: avg([
        Math.round((p.signals.scores.titleScore + p.signals.scores.descriptionScore) / 2),
        Math.round((p.signals.scores.structureScore + p.signals.scores.contentScore) / 2),
        Math.round((p.signals.scores.trustScore + p.signals.scores.altScore) / 2),
        p.signals.scores.analyticsScore
      ])
    })),
    psi: {
      performance: perf,
      accessibility: acc,
      seo,
      lcp: psi?.lighthouseResult?.audits?.['largest-contentful-paint']?.displayValue || '—',
      cls: psi?.lighthouseResult?.audits?.['cumulative-layout-shift']?.displayValue || '—',
      tbt: psi?.lighthouseResult?.audits?.['total-blocking-time']?.displayValue || '—',
      loadingCategory: psi?.loadingExperience?.overall_category || 'UNKNOWN'
    },
    criteria,
    scores: { total, metadata, structure, trust, analyticsScore, socialScore, localScore: listingSignals.score, crawlScore },
    formula: rules.formula,
    criteriaMeta: rules.criteria,
    personalizedRecommendations
  };
}

function buildContentPlan(audit) {
  const channels = [];
  if (audit.socialLinks.telegram.length || audit.socialLinks.vk.length) channels.push('Telegram/VK');
  if (audit.socialLinks.youtube.length) channels.push('YouTube');
  if (!channels.length) channels.push('Сайт и блог');
  const topics = [
    'Ответы на частые вопросы клиентов',
    'Кейсы и примеры результатов',
    'Разбор типичных ошибок клиентов',
    'Объяснение продукта или услуги простым языком',
    'Сравнение решений и сценариев использования'
  ];
  return topics.map((topic, i) => ({ week: i + 1, topic, channel: channels[i % channels.length], format: i % 2 === 0 ? 'Пост + карточка' : 'Короткий экспертный материал', goal: i % 2 === 0 ? 'Доверие и охват' : 'Лиды и прогрев' }));
}

function buildDeveloperBrief(audit) {
  const tasks = [];
  if (audit.psi.performance < 70) tasks.push({ priority:'high', area:'performance', task:'Оптимизировать LCP/TBT, сжать изображения, отложить тяжёлые скрипты.', acceptance:'Performance score >= 70.' });
  if (audit.h1Count !== 1) tasks.push({ priority:'high', area:'content', task:'Привести структуру заголовков к одному H1 и логичным H2.', acceptance:'На главной странице ровно один H1.' });
  if (audit.altMissing > 0) tasks.push({ priority:'medium', area:'accessibility', task:'Добавить alt-атрибуты критичным изображениям.', acceptance:'Alt отсутствует не более чем у 5% изображений.' });
  if (!audit.metaDescription) tasks.push({ priority:'medium', area:'seo', task:'Добавить meta description с ценностным оффером.', acceptance:'Description длиной 70-170 символов присутствует.' });
  if (!audit.robots.ok) tasks.push({ priority:'medium', area:'seo', task:'Добавить robots.txt.', acceptance:'Файл robots.txt доступен по /robots.txt.' });
  if (!audit.sitemap.ok) tasks.push({ priority:'medium', area:'seo', task:'Добавить sitemap.xml и связать его с robots.txt.', acceptance:'Файл sitemap.xml доступен.' });
  if (audit.analyticsScore < 50) tasks.push({ priority:'high', area:'analytics', task:'Подключить или проверить корректность счетчиков аналитики.', acceptance:'На сайте определяются Метрика, Analytics или GTM.' });
  if (audit.pagesAnalyzed > 1) tasks.push({ priority:'medium', area:'site-structure', task:'Выравнять ключевые страницы по title, description, H1 и CTA.', acceptance:'Средний pageHealth по страницам >= 75.' });
  return tasks;
}

function buildRoleActions(audit) {
  return {
    owner: [
      `Сфокусироваться на критериях ниже 65: ${audit.criteria.filter(x => x.score < 65).map(x => x.title).join(', ') || 'критичных просадок нет'}.`,
      'Проверить, отражает ли сайт ценность бизнеса и путь к заявке.',
      'Определить KPI после внедрения правок: заявки, трафик, CTR, звонки.'
    ],
    marketer: [
      'Усилить оффер, CTA и контент вокруг ключевых страниц.',
      'Сформировать контент-план по темам доверия, экспертизы и прогрева.',
      'Связать сайт, соцсети и карточки компании в единую digital-цепочку.'
    ],
    developer: buildDeveloperBrief(audit).map(x => `${x.priority.toUpperCase()}: ${x.task}`),
    analyst: [
      'Сопоставить наличие аналитики с целями бизнеса и событиями конверсии.',
      'Повторять аудит после внедрения изменений.',
      'Отслеживать метрики скорости, SEO и поведенческих сигналов.'
    ]
  };
}

async function generateAiSummary(project, audit) {
  const userPrompt = `Проект: ${project.name}. URL: ${project.website}. Тип бизнеса: ${project.businessType}. Цель: ${project.goal || 'не указана'}. Контекст: ${project.description || 'не указан'}. Общий коэффициент: ${audit.scores.total}/100. Формула: ${audit.formula}. Проанализировано страниц: ${audit.pagesAnalyzed}. Скорость: ${audit.psi.performance}, Доступность: ${audit.psi.accessibility}, SEO: ${audit.psi.seo}, Метаданные: ${audit.scores.metadata}, Структура: ${audit.scores.structure}, Доверие: ${audit.scores.trust}, Аналитика: ${audit.analyticsScore}, Соцсети: ${audit.scores.socialScore}, Карточки: ${audit.scores.localScore}, Охват страниц: ${audit.scores.crawlScore}. Robots: ${audit.robots.ok}. Sitemap: ${audit.sitemap.ok}. Broken links: ${audit.brokenLinks.length}. Персональные рекомендации: ${audit.personalizedRecommendations.map(x => x.title).join(', ')}. Ответь на русском, строго в Markdown. Блоки: 1) Общая оценка 2) Почему оценка объективна 3) Персональные рекомендации под цель бизнеса 4) Что сделать за 7 дней 5) Как измерить эффект.`;
  if (!VSEGPT_KEY) return `### Общая оценка\nСайт получил **${audit.scores.total}/100**. Оценка считается как **среднее арифметическое всех критериев**.\n\n### Почему оценка объективна\n- Анализируется не только главная страница, но и несколько страниц сайта\n- Учитываются скорость, SEO, структура, доверие, аналитика, соцсети и карточки компании\n- Видно, какие сигналы действительно обнаружены на сайте\n\n### Персональные рекомендации\n${audit.personalizedRecommendations.map(x => `- **${x.priority.toUpperCase()}**: ${x.title} — ${x.description}`).join('\n') || '- Значимых персональных рекомендаций пока нет'}\n\n### Что сделать за 7 дней\n- Исправить критичные критерии ниже 65\n- Подключить аналитику и проверить конверсии\n- Усилить ключевые страницы и CTA\n\n### Как измерить эффект\n- Сравнить score до и после\n- Проверить заявки, звонки, CTR и скорость`; 
  const r = await fetch('https://api.vsegpt.ru/v1/chat/completions', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${VSEGPT_KEY}` },
    body: JSON.stringify({ model: VSEGPT_MODEL, messages: [{ role:'system', content:'Ты цифровой советник для бизнеса. Отвечай объективно, на русском, в Markdown.' }, { role:'user', content: userPrompt }], temperature: 0.35, max_tokens: 1500 })
  });
  const txt = await r.text();
  if (!r.ok) throw new Error(txt.slice(0,300));
  const data = JSON.parse(txt);
  return data?.choices?.[0]?.message?.content || '';
}

app.get('/api/health', async (_, res) => res.json({ ok:true, time:new Date().toISOString() }));
app.get('/api/knowledge-base', async (_, res) => res.json(await readJson(KNOWLEDGE_FILE)));
app.post('/api/knowledge-base/refresh', async (_, res) => { const kb = await readJson(KNOWLEDGE_FILE); kb.updatedAt = new Date().toISOString(); kb.categories.analytics.push('Проверяйте события, цели и корректность работы счетчиков на всех ключевых страницах.'); await writeJson(KNOWLEDGE_FILE, kb); res.json({ ok:true, updatedAt: kb.updatedAt }); });
app.get('/api/rules', async (_, res) => res.json(await readJson(RULES_FILE)));
app.get('/api/users', async (_, res) => { const db = await readJson(DB_FILE); res.json(db.users); });
app.get('/api/projects', async (_, res) => { const db = await readJson(DB_FILE); res.json(db.projects); });
app.post('/api/projects', async (req, res) => {
  const db = await readJson(DB_FILE);
  const { name, website, businessType='services', description='', socialProfiles={}, companyProfiles={}, goal='' } = req.body || {};
  const project = { id: uid('prj'), name, website: normUrl(website), businessType, description, socialProfiles, companyProfiles, goal, createdAt: new Date().toISOString() };
  db.projects.unshift(project); await writeJson(DB_FILE, db); res.json(project);
});
app.get('/api/projects/:id', async (req, res) => { const db = await readJson(DB_FILE); const project = db.projects.find(x => x.id === req.params.id); if (!project) return res.status(404).send('Project not found'); const audits = db.audits.filter(x => x.projectId === project.id).sort((a,b)=>b.createdAt.localeCompare(a.createdAt)); res.json({ project, audits }); });
app.post('/api/projects/:id/audit', async (req, res) => {
  try {
    const db = await readJson(DB_FILE);
    const project = db.projects.find(x => x.id === req.params.id); if (!project) return res.status(404).send('Project not found');
    const audit = await analyzeWebsite(project.website, project.businessType, project.goal, project.description);
    const contentPlan = buildContentPlan(audit);
    const developerBrief = buildDeveloperBrief(audit);
    const roleActions = buildRoleActions(audit);
    const aiSummary = await generateAiSummary(project, audit);
    const record = { id: uid('aud'), projectId: project.id, createdAt: new Date().toISOString(), audit, contentPlan, developerBrief, roleActions, aiSummary };
    db.audits.unshift(record); await writeJson(DB_FILE, db); res.json(record);
  } catch (e) { res.status(500).send(e.message); }
});
app.get('/api/jobs', async (_, res) => { const db = await readJson(DB_FILE); res.json(db.jobs); });
app.post('/api/jobs', async (req, res) => {
  const db = await readJson(DB_FILE);
  const { projectId, intervalMinutes = JOB_INTERVAL_MINUTES, enabled = true } = req.body || {};
  const job = { id: uid('job'), projectId, intervalMinutes, enabled: enabled !== false, lastRunAt: null, nextRunAt: new Date(Date.now() + intervalMinutes*60000).toISOString(), createdAt: new Date().toISOString() };
  db.jobs.unshift(job); await writeJson(DB_FILE, db); res.json(job);
});
async function runScheduledJobs() {
  const db = await readJson(DB_FILE);
  const now = Date.now(); let changed = false;
  for (const job of db.jobs) {
    if (!job.enabled) continue;
    if (!job.nextRunAt || new Date(job.nextRunAt).getTime() <= now) {
      const project = db.projects.find(x => x.id === job.projectId); if (!project) continue;
      try {
        const audit = await analyzeWebsite(project.website, project.businessType, project.goal, project.description);
        const contentPlan = buildContentPlan(audit); const developerBrief = buildDeveloperBrief(audit); const roleActions = buildRoleActions(audit); const aiSummary = await generateAiSummary(project, audit);
        db.audits.unshift({ id: uid('aud'), projectId: project.id, createdAt: new Date().toISOString(), audit, contentPlan, developerBrief, roleActions, aiSummary, source:'scheduler' });
        job.lastRunAt = new Date().toISOString(); job.nextRunAt = new Date(Date.now() + job.intervalMinutes*60000).toISOString(); changed = true;
      } catch (e) { job.lastError = e.message; job.nextRunAt = new Date(Date.now() + job.intervalMinutes*60000).toISOString(); changed = true; }
    }
  }
  if (changed) await writeJson(DB_FILE, db);
}
setInterval(() => { runScheduledJobs().catch(()=>{}); }, 60 * 1000);
app.listen(PORT, () => console.log(`Growth Auditor V4 running on ${BASE_URL}`));
